import urllib
import requests
import matplotlib.pyplot as plt
import numpy as np
from io import BytesIO
import base64
from wordcloud import WordCloud

def query(GET, field=None, facet=False):
    queryList = []
    for instance in GET:
        queryList.append((instance, GET[instance]))

    query_url = generate_url(dict(queryList[:2]), dict(queryList[2:]), field, facet)
    query_object = requests.get(query_url)

    return query_object.json()

def generate_url(mainQueryDict, sideQueryDict, field=None, facet=False):

    if facet:
        url = 'http://localhost:8983/solr/covid/select?facet.field={}&facet=on&q='.format(field)
    else:
        url = 'http://localhost:8983/solr/covid/select?q='
    
    main_query_list = []
    for instance in mainQueryDict:
        if mainQueryDict[instance]:
            query = urllib.parse.quote('{}:{}'.format(instance, mainQueryDict[instance].lower()), safe='')
            main_query_list.append(query)
    
    connector = urllib.parse.quote('\n', safe='')
    query = connector.join(main_query_list)

    url += query

    if 'Search' in sideQueryDict:
            sideQueryDict.pop('Search')

    if sideQueryDict:

        sideQuery = urllib.parse.urlencode(sideQueryDict)
        url = url + '&' + sideQuery

    print(url)
    print(mainQueryDict)
    print(repr(sideQueryDict))
    return url

def evaluate_facet_fields(facet_fields, size):
    words = []
    counts = []
    for field in facet_fields[:size*2]:
        if isinstance(field, str):
            words.append(field)
        elif isinstance(field, int):
            counts.append(field)
    return words, counts

def get_graph():
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    graph = base64.b64encode(image_png)
    graph = graph.decode('utf-8')
    buffer.close()
    return graph

def get_plot(words, counts):
    plt.switch_backend('AGG')
    fig, ax = plt.subplots()
    fig.set_figheight(10)
    fig.set_figwidth(10)

    y_pos = np.arange(len(words))
    x_pos = np.asarray(counts)

    ax.barh(y_pos, x_pos, align='center')
    ax.set_yticks(y_pos)
    ax.set_yticklabels(words)
    ax.invert_yaxis()  # labels read top-to-bottom
    ax.set_xlabel('Word Count')
    # ax.set_title('Bar Chart')
    for i, v in enumerate(counts):
        ax.text(v + 1, i + .3, str(v), color='black')

    graph = get_graph()
    return graph


def get_word_cloud(word_list):
    plt.switch_backend('AGG')
    
    text = ' '.join(word_list)
    # text = 'hello im here to find apples and shop with'

    # Create and generate a word cloud image:
    wordcloud = WordCloud(max_font_size=80, background_color="white").generate(text)
    # Display the generated image:
    plt.figure(figsize=(18,9))
    
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis("off")

    graph = get_graph()
    return graph

# import folium
# from geopy.geocoders import Nominatim
# def get_map(countries, counts):
#     # Create Map
#     geo_map = folium.Map()

#     info_list = []
#     for country, count in zip(countries, counts):
        
#         try:
#             locator = Nominatim(user_agent='myGeocoder')
#             location = locator.geocode(country)
#             latitude = location.latitude
#             longitude = location.longitude
#         except:
#             latitude = None
#             longitude = None

#         # print('Latitude = {}, Longitude = {}'.format(location.latitude, location.longitude))
#         country_dict = { 'country': country, 'count':count, 'latitude':latitude, 'longitude':longitude}
#         info_list.append(country_dict)
#     print(info_list)


#     # Get html representation of map
#     geo_map = geo_map._repr_html_()

#     return geo_map

# def redirect_with_params(viewname, **kwargs):
#     """
#     Redirect a view with params
#     """
#     rev = reverse(viewname)

#     params = urllib.parse.urlencode(kwargs)
#     if params:
#         rev = '{}?{}'.format(rev, params)

#     return HttpResponseRedirect(rev)

