from django import forms

class QueryForm(forms.Form):
    Processed = forms.CharField(
        required=False,
        label='Search by Content',
        widget=forms.TextInput(
            attrs={
                'class':'form-control'
            }
        ),
    )
    
    Location = forms.CharField(
        required=False,
        label='Search by Location',
        widget=forms.TextInput(
            attrs={
                'class':'form-control'
            }
        ),
    )


class ItemsPerPageForm(forms.Form):
    CHOICES = [
        ('5', '5'),
        ('10', '10'),
        ('15', '15'),
    ]

    items_per_page = forms.ChoiceField(
        required=False,
        widget=forms.Select(
            attrs={
                'class':'form-select',
            }
        ),
        choices=CHOICES,
        
    )