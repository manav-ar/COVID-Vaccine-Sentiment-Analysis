from django import template
from django.template.defaultfilters import stringfilter

register = template.Library()

@register.filter
@stringfilter
def sub(value1, value2):
    return int(value1)-int(value2)

@register.filter
@stringfilter
def mul(value1, value2):
    return int(value1) * int(value2)

@register.filter
@stringfilter
def div(value1, value2):
    return int(int(value1) / int(value2))