from django.shortcuts import render, redirect, reverse, HttpResponseRedirect
from query.forms import QueryForm, ItemsPerPageForm
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .utils import query, get_plot, get_word_cloud, evaluate_facet_fields


#
# Query View
#
def query_view(request):
    
    return render(request, 'query/query.html', {})

#
# Results View
#
def results_view(request):

    context = {}
    query_object = {}
    tweets = []
    qTimes = []
    numFound = 0
    numPage = 0
    facet_size = 50
    result_count = None

    processed = request.GET.get('Processed')
    location = request.GET.get('Location')
    rows = request.GET.get('rows')
    start = request.GET.get('start')
    search_type = request.GET.get('Search')

    if search_type == 'Enhanced':

        try:
            query_object = query(request.GET, field='Processed', facet=True)
            facet_fields = query_object['facet_counts']['facet_fields']['Processed']
            # print(facet_fields)
            result_count = query_object['response']['numFound']
            words, counts = evaluate_facet_fields(facet_fields, facet_size)

            histogram = get_plot(words, counts)
            word_cloud = get_word_cloud(words)
            context = {
                'histogram': histogram,
                'word_cloud': word_cloud,
                'result_count': result_count
            }

            return render(request, 'query/enhanced_query.html', context)

        except:
            context['error'] = 'Bad Data'
            return render(request, 'query/results.html', context)

    # elif search_type == 'Geo':

    #     try:
    #         query_object = query(request.GET, field='Location', facet=True)
    #         facet_fields = query_object['facet_counts']['facet_fields']['Location']
    #         print(facet_fields)
    #         countries, counts = evaluate_facet_fields(facet_fields, facet_size)

    #         geo_map = get_map(countries, counts)
    #         context = {
    #             'geo_map': geo_map,
    #         }

    #         return render(request, 'query/geo_query.html', context)
    #     except:
    #         context['error'] = 'Bad Data'
    #         return render(request, 'query/results.html', context)
        
        

    else:
        rows = int(rows) if rows else 10
        start = int(start) if start else 0

        try:
            query_object = query(request.GET, facet=False)
            result_count = query_object['response']['numFound']
        except:
            context['error'] = 'Bad Data'
            return render(request, 'query/results.html', context)

        try:
            qTimes = request.session['qTimes']
        except:
            pass

        if not 'error' in query_object:
            tweets = query_object['response']['docs']
            numFound = query_object['response']['numFound']
            if int(numFound) % rows != 0:
                numPage = int(int(numFound) / rows) + 1
            else:
                numPage = int(int(numFound) / rows)
            
        qtime_object = {'processed':processed, 'location':location, 'qTime': query_object['responseHeader']['QTime']}
        qTimes.append(qtime_object)
        request.session['qTimes'] = qTimes
        
        if request.method == 'POST':
            request.session.clear()
            qTimes = []

        # add tweets object
        context['result_count'] = result_count
        context['tweets'] = tweets
        context['qTimes'] = qTimes
        context['start'] = start
        context['rows'] = rows
        context['numFound'] = numFound
        context['numPage'] = numPage
        context['page_list'] = [i for i in range(numPage)]

        # print(start)
        # print(type(start))
        # print(rows)
        # print(type(rows))
        # print(numFound)
        # print(type(numFound))
        # print(numPage)
        # print(type(numPage))

        return render(request, 'query/simple_search.html', context)

