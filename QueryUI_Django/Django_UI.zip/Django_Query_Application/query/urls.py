from django.urls import path, re_path
from query import views

app_name = 'query'
urlpatterns = [
    path('', views.query_view, name='query_view'),
    path('<slug>', views.query_view, name='query_view'),
    path('results/', views.results_view, name='results_view'),
] 
