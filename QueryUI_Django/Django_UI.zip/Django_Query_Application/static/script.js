try {
    const processedInput = document.getElementById('Processed')
    const locationInput = document.getElementById('Location')
    const queryForm = document.getElementById('queryForm')

    queryForm.addEventListener('submit', (e)=>{
        // console.log(processedInput.value)
        // console.log(locationInput.value)

        if (!processedInput.value.replace(/\s/g, '').length) {
            processedInput.value = ""
            if (!locationInput.value.replace(/\s/g, '').length) {
                locationInput.value = ""
                // console.log('prevent')
                e.preventDefault()
            }
        }
        if (!locationInput.value.replace(/\s/g, '').length) {
            locationInput.value = ""
        }

    })

    const scroll_table = document.getElementById("scroll-table")
    scroll_table.scrollTop = scroll_table.scrollHeight;
} catch(e) {
    if (e instanceof TypeError){

    }
    else {
        console.log(e)
    }
}